# Ads API by stark AI

Manage supported OpenAI Ads resources with a connected Advertiser API account. Inspect campaigns and reports, prepare requests, and perform authorized campaign, bulk, feed, audience and conversion-setup operations. Complements the official Ads Manager plugin where its available tools lack an operation or parameter, and supports API workflows without that plugin.

Requires an Ads account and an account-scoped Advertiser API key from Ads Manager. A regular OpenAI Platform key is not a substitute. This independent integration is published by servrox solutions UG, not OpenAI. Its hosted MCP service receives the requested Ads data and stores the connected Ads key encrypted. API availability remains subject to OpenAI account access and feature enablement. Installation grants no advertising-spend authorization.

This generated package contains the unchanged canonical openai-advertiser-api skill and the OAuth-enabled remote MCP connection at https://stark-ai-ads-mcp.vercel.app/mcp.

The server is deployed separately; installing this archive does not deploy it. Configure the public client stark-ai-ads-chatgpt with the exact callback URL displayed by the OpenAI connection flow.

Package checks do not establish service availability, Ads account access, completed review or public publication. See https://github.com/stark-ai-de/agent-skills/blob/main/docs/listing/openai/stark-ai-ads.md.
